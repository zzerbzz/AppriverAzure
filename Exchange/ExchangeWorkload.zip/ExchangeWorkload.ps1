#
# Copyright="© Microsoft Corporation. All rights reserved."
#

configuration InstallAndConfigureExchange
{
	param
    (
		[Parameter(Mandatory=$true)]
		[String]$DomainName,

		[Parameter(Mandatory=$true)]
		[String]$StorageSize,

		[Parameter(Mandatory=$true)]
		[PSCredential]$VMAdminCreds,

		[Parameter(Mandatory=$true)]
		[String]$Location
	)

	$DomainCreds = [System.Management.Automation.PSCredential]$DomainFQDNCreds = New-Object System.Management.Automation.PSCredential ("${DomainName}\$($VMAdminCreds.UserName)", $VMAdminCreds.Password)

	Import-DscResource -ModuleName 'PSDesiredStateConfiguration';
	Import-DscResource -ModuleName xActiveDirectory;
	Import-DscResource -ModuleName xDisk;
	Import-DscResource -ModuleName xDownloadFile;
	Import-DscResource -ModuleName xDownloadISO;
    Import-DscResource -ModuleName xExchange;
	Import-DscResource -ModuleName xExchangeValidate;
	Import-DscResource -ModuleName xExtract;
	Import-DscResource -ModuleName xInstaller;
	Import-DscResource -ModuleName xPendingReboot;
	Import-DscResource -ModuleName xPSDesiredStateConfiguration;
	Import-DscResource -ModuleName xPSWindowsUpdate;

	# Downloaded file storage location
	$downloadPath = "$env:SystemDrive\DownloadsForDSC";
	$exchangeInstallerPath = "$env:SystemDrive\InstallerExchange";
	$diskNumber = 2;
	
	Install-WindowsFeature Server-Media-Foundation, NET-Framework-45-Features, RPC-over-HTTP-proxy, RSAT-Clustering, RSAT-Clustering-CmdInterface, RSAT-Clustering-PowerShell, WAS-Process-Model, Web-Asp-Net45, Web-Basic-Auth, Web-Client-Auth, Web-Digest-Auth, Web-Dir-Browsing, Web-Dyn-Compression, Web-Http-Errors, Web-Http-Logging, Web-Http-Redirect, Web-Http-Tracing, Web-ISAPI-Ext, Web-ISAPI-Filter, Web-Metabase, Web-Mgmt-Service, Web-Net-Ext45, Web-Request-Monitor, Web-Server, Web-Stat-Compression, Web-Static-Content, Web-Windows-Auth, Web-WMI, RSAT-ADDS, BitLocker, snmp-Service, snmp-wmi-provider, Web-Scripting-Tools, Web-Server -IncludeManagementTools
	
	Node localhost
    {
		xWaitforDisk Disk2
        {
            DiskNumber = $diskNumber
            RetryIntervalSec = 60
            RetryCount = 60
        }
        xDisk Volume
        {
			DiskNumber = $diskNumber
            DriveLetter = 'F'
			DependsOn = '[xWaitforDisk]Disk2'
        }
		xPSWindowsUpdate InstallNet45
		{
			KBArticleID = "2934520"
			DependsOn = '[xDisk]Volume'
		}
		# Reboot node if necessary
		xPendingReboot RebootPostInstallNet45
        {
            Name      = "AfterNet452"
			DependsOn = "[xPSWindowsUpdate]InstallNet45"
        }
		# Install Exchange 2016 Pre-requisits | Reference: https://technet.microsoft.com/en-us/library/bb691354(v=exchg.160).aspx
		# Active Directory
		WindowsFeature RSATADDS {
			Name = "RSAT-ADDS"
            Ensure = "Present"
			DependsOn = "[xPendingReboot]RebootPostInstallNet45"
		}
		WindowsFeature WebStatCompression
		{
			Name = "Web-Stat-Compression"
			Ensure = "Present"
		}
		WindowsFeature WebStaticContent
		{
			Name = "Web-Static-Content"
			Ensure = "Present"
			DependsOn = "[WindowsFeature]WebStatCompression"
		}
		WindowsFeature WebWindowsAuth
		{
			Name = "Web-Windows-Auth"
			Ensure = "Present"
			DependsOn = "[WindowsFeature]WebStaticContent"
		}
		WindowsFeature WebWMI
		{
			Name = "Web-WMI"
			Ensure = "Present"
			DependsOn = "[WindowsFeature]WebWindowsAuth"
		}
		WindowsFeature WindowsIdentityFoundation
		{
			Name = "Windows-Identity-Foundation"
			Ensure = "Present"
			DependsOn = "[WindowsFeature]WebWMI"
		}
		
		# Edge Transport Server Role
		WindowsFeature ADLDS
		{
			Name = "ADLDS"
			Ensure = "Present"
			DependsOn = "[WindowsFeature]WindowsIdentityFoundation"
		}
		# DNS
		WindowsFeature DNS
		{
			Name = "DNS"
			Ensure = "Present"
			DependsOn = "[WindowsFeature]ADLDS"
		}
		# Active Directory Domain Service
		WindowsFeature ADDSInstall
		{
			Name = "AD-Domain-Services"
			Ensure = "Present"
			DependsOn = "[WindowsFeature]DNS"
		}
		xPendingReboot RebootPostADDSInstall
		{
			Name = "AfterADDSInstall"
			DependsOn = "[WindowsFeature]ADDSInstall"
		}
		# AD Domain creation needs a reboot
		xADDomain FirstDS 
        {
            DomainName = $DomainName
            DomainAdministratorCredential = $DomainCreds
            SafemodeAdministratorPassword = $DomainCreds
            DatabasePath = "$env:SystemDrive\NTDS"
            LogPath = "$env:SystemDrive\NTDS"
            SysvolPath = "$env:SystemDrive\SYSVOL"
			DependsOn = "[xPendingReboot]RebootPostADDSInstall"
        }
		# Reboot node if necessary
		xPendingReboot RebootPostFirstDS
        {
            Name      = "AfterFirstDS"
            DependsOn = "[xADDomain]FirstDS"
        }
        # Download Unified Communication Manager API 4.0
        xDownloadFile DownloadUCMA4
		{
			SourcePath = "https://download.microsoft.com/download/2/C/4/2C47A5C1-A1F3-4843-B9FE-84C0032C61EC/UcmaRuntimeSetup.exe"
			FileName = "UcmaRuntimeSetup.exe"
			DestinationDirectoryPath = $downloadPath
			DependsOn = "[xPendingReboot]RebootPostFirstDS"
		}
		# Install Unified Communication Manager API 4.0
        xInstaller InstallUCMA4
		{
			Path = "$downloadPath\UcmaRuntimeSetup.exe"
			Arguments = "-q"
			RegistryKey = "NA"
			DependsOn = "[xDownloadFile]DownloadUCMA4"
		}
		# Reboot node if necessary
		xPendingReboot RebootPostInstallUCMA4
        {
            Name      = "AfterUCMA4"
            DependsOn = "[xInstaller]InstallUCMA4"
        }
		# Install Exchange 2016 CU1
        xExchInstall InstallExchange
        {
            Path = "$exchangeInstallerPath\setup.exe"
            Arguments = "/Mode:Install /Role:Mailbox /OrganizationName:exgappriverdev /TargetDir:F:\Exchange /IAcceptExchangeServerLicenseTerms"
            Credential = $DomainCreds
            DependsOn = '[xPendingReboot]RebootPostInstallUCMA4'
			PsDscRunAsCredential = $DomainCreds
        }
		#xExchangeValidate ValidateExchange2016
		#{
		#	TestName = "All"
		#	DependsOn = "[xInstaller]DeployExchangeCU1"
		#}
		# Reboot node if needed
		LocalConfigurationManager 
        {
			ConfigurationMode = 'ApplyOnly'
            RebootNodeIfNeeded = $True
        }
	}
}
