#
# Copyright="© Microsoft Corporation. All rights reserved."
#

configuration InstallAndConfigureExchange
{
	param
	(
		[Parameter(Mandatory = $true)]
		[String]$DomainName,
		[Parameter(Mandatory = $true)]
		[String]$StorageSize,
		[Parameter(Mandatory = $true)]
		[PSCredential]$VMAdminCreds,
		[Parameter(Mandatory = $true)]
		[String]$Location
	)
	
	$DomainCreds = [System.Management.Automation.PSCredential]$DomainFQDNCreds = New-Object System.Management.Automation.PSCredential ("${DomainName}\$($VMAdminCreds.UserName)", $VMAdminCreds.Password)
	
	Import-DscResource -ModuleName 'PSDesiredStateConfiguration';
	Import-DscResource -ModuleName xActiveDirectory;
	Import-DscResource -ModuleName xDisk;
	Import-DscResource -ModuleName xDownloadFile;
	Import-DscResource -ModuleName xDownloadISO;
	Import-DscResource -ModuleName xExchange;
	Import-DscResource -ModuleName xExchangeValidate;
	Import-DscResource -ModuleName xExtract;
	Import-DscResource -ModuleName xInstaller;
	Import-DscResource -ModuleName xPendingReboot;
	Import-DscResource -ModuleName xNetworking;
	Import-DscResource -ModuleName xPSDesiredStateConfiguration;
	Import-DscResource -ModuleName xPSWindowsUpdate;
	
	# Downloaded file storage location
	$downloadPath = "C:\DownloadsForDSC";
	$exchangeInstallerPath = "C:\InstallerExchange";
	$diskNumber = 2;
	
	$Interface = Get-NetAdapter | Where Name -Like "Ethernet*" | Select-Object -First 1
	$InterfaceAlias = $($Interface.Name)
	
	Install-WindowsFeature Server-Media-Foundation, NET-Framework-45-Features, RPC-over-HTTP-proxy, RSAT-Clustering, RSAT-Clustering-CmdInterface, RSAT-Clustering-PowerShell, WAS-Process-Model, Web-Asp-Net45, Web-Basic-Auth, Web-Client-Auth, Web-Digest-Auth, Web-Dir-Browsing, Web-Dyn-Compression, Web-Http-Errors, Web-Http-Logging, Web-Http-Redirect, Web-Http-Tracing, Web-ISAPI-Ext, Web-ISAPI-Filter, Web-Metabase, Web-Mgmt-Service, Web-Net-Ext45, Web-Request-Monitor, Web-Server, Web-Stat-Compression, Web-Static-Content, Web-Windows-Auth, Web-WMI, RSAT-ADDS, BitLocker, snmp-Service, snmp-wmi-provider, Web-Scripting-Tools, Web-Server -IncludeManagementTools
	
	Node localhost
	{
		xWaitforDisk Disk2
		{
			DiskNumber = $diskNumber
			RetryIntervalSec = 60
			RetryCount = 60
		}
		xDisk Volume
		{
			DiskNumber = $diskNumber
			DriveLetter = 'F'
			DependsOn = '[xWaitforDisk]Disk2'
		}
		xPSWindowsUpdate InstallNet45
		{
			KBArticleID = "2934520"
			DependsOn = '[xDisk]Volume'
		}
		# Reboot node if necessary
		xPendingReboot RebootPostInstallNet45
		{
			Name = "AfterNet452"
			DependsOn = "[xPSWindowsUpdate]InstallNet45"
		}
		# Install Exchange 2016 Pre-requisits | Reference: https://technet.microsoft.com/en-us/library/bb691354(v=exchg.160).aspx
		# Active Directory
		WindowsFeature RSATADDS
		{
			Name = "RSAT-ADDS"
			Ensure = "Present"
			DependsOn = "[xPendingReboot]RebootPostInstallNet45"
		}
		WindowsFeature WebStatCompression
		{
			Name = "Web-Stat-Compression"
			Ensure = "Present"
		}
		WindowsFeature WebStaticContent
		{
			Name = "Web-Static-Content"
			Ensure = "Present"
			DependsOn = "[WindowsFeature]WebStatCompression"
		}
		WindowsFeature WebWindowsAuth
		{
			Name = "Web-Windows-Auth"
			Ensure = "Present"
			DependsOn = "[WindowsFeature]WebStaticContent"
		}
		WindowsFeature WebWMI
		{
			Name = "Web-WMI"
			Ensure = "Present"
			DependsOn = "[WindowsFeature]WebWindowsAuth"
		}
		WindowsFeature WindowsIdentityFoundation
		{
			Name = "Windows-Identity-Foundation"
			Ensure = "Present"
			DependsOn = "[WindowsFeature]WebWMI"
		}
		# Edge Transport Server Role
		WindowsFeature ADLDS
		{
			Name = "ADLDS"
			Ensure = "Present"
			DependsOn = "[WindowsFeature]WindowsIdentityFoundation"
		}
		# DNS
		WindowsFeature DNS
		{
			Ensure = "Present"
			Name = "DNS"
		}
		
		Script EnableDNSDiags
		{
			SetScript = {
				Set-DnsServerDiagnostics -All $true
				Write-Verbose -Verbose "Enabling DNS client diagnostics"
			}
			GetScript = { @{ } }
			TestScript = { $false }
			DependsOn = "[WindowsFeature]DNS"
		}
		WindowsFeature DnsTools
		{
			Ensure = "Present"
			Name = "RSAT-DNS-Server"
			DependsOn = "[WindowsFeature]DNS"
		}
		xDnsServerAddress DnsServerAddress
		{
			Address = '127.0.0.1'
			InterfaceAlias = $InterfaceAlias
			AddressFamily = 'IPv4'
			DependsOn = "[WindowsFeature]DNS"
		}
		WindowsFeature ADDSInstall
		{
			Ensure = "Present"
			Name = "AD-Domain-Services"
			DependsOn = "[WindowsFeature]DNS"
		}
		
		WindowsFeature ADDSTools
		{
			Ensure = "Present"
			Name = "RSAT-ADDS-Tools"
			DependsOn = "[WindowsFeature]ADDSInstall"
		}
		
		WindowsFeature ADAdminCenter
		{
			Ensure = "Present"
			Name = "RSAT-AD-AdminCenter"
			DependsOn = "[WindowsFeature]ADDSInstall"
		}
		xPendingReboot RebootPostADDSInstall
		{
			Name = "AfterADDSInstall"
			DependsOn = "[WindowsFeature]ADDSInstall"
		}
		# AD Domain creation needs a reboot
		<#
		xADDomain FirstDS
		{
			DomainName = $DomainName
			DomainAdministratorCredential = $DomainCreds
			SafemodeAdministratorPassword = $DomainCreds
			DatabasePath = "F:\NTDS"
			LogPath = "F:\Logs"
			SysvolPath = "F:\SYSVOL"
			DependsOn = "[xPendingReboot]RebootPostADDSInstall"
		}
		#>
		Install-WindowsFeature AD-Domain-Services -IncludeManagementTools
		Import-Module ADDSDeployment
		$Pass = '!96En0va$Azure' | ConvertTo-SecureString -asPlainText -Force
		Install-ADDSForest -DomainName "EXGAppriverDEV.test" -DatabasePath "F:\NTDS" -SysvolPath "F:\SYSVOL" -LogPath "F:\Logs" -SafeModeAdministratorPassword $Pass -confirm:$False
		# Reboot node if necessary
		xPendingReboot RebootPostFirstDS
		{
			Name = "AfterFirstDS"
		}
		# Install Exchange 2016 CU1

		Arguments = "/Mode:Install /Role:Mailbox /OrganizationName:exgappriverdev /TargetDir:F:\Exchange /IAcceptExchangeServerLicenseTerms"
		cd $exchangeInstallerPath
		Set-Location $exchangeInstallerPath
		.\setup.exe /preparead /OrganizationName:exgappriverdev /IAcceptExchangeServerLicenseTerms
		
		.\setup.exe /mode:Install /role:Mailbox /OrganizationName:exgappriverdev /IacceptExchangeServerLicenseTerms
		

		
		#xExchangeValidate ValidateExchange2016
		#{
		#	TestName = "All"
		#	DependsOn = "[xInstaller]DeployExchangeCU1"
		#}
		# Reboot node if needed
		LocalConfigurationManager
		{
			ConfigurationMode = 'ApplyOnly'
			RebootNodeIfNeeded = $True
		}
	}
}
